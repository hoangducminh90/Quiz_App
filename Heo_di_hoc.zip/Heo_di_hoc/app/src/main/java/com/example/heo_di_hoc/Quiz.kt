package com.example.heo_di_hoc

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun QuizScreen(quizSets: List<QuizSet>) {
    var currentQuizIndex by remember { mutableStateOf(0) }
    var selectedOption by remember { mutableStateOf(-1) }
    var isLocked by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(mutableListOf<String>()) }
    var showResults by remember { mutableStateOf(false) }

    val currentQuiz = quizSets[currentQuizIndex]
    val options = listOf(currentQuiz.answer1, currentQuiz.answer2, currentQuiz.answer3, currentQuiz.answer4)

    if (!showResults) {
        if (currentQuizIndex < quizSets.size) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Question ${currentQuiz.id}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp)
                    ) {
                        Text(
                            text = currentQuiz.question,
                            fontSize = 18.sp,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    ) {
                        options.forEachIndexed { index, option ->
                            val isCorrectAnswer = currentQuiz.correctAnswer == index + 1
                            val isSelectedOption = selectedOption == index + 1
                            val backgroundColor = when {
                                isSelectedOption && isCorrectAnswer -> Color.Green
                                isSelectedOption && !isCorrectAnswer -> Color.Red
                                else -> Color.White
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                                    .background(
                                        color = backgroundColor,
                                        shape = RoundedCornerShape(8.dp),
                                    )
                                    .clickable(enabled = !isLocked) {
                                        selectedOption = index + 1
                                        isLocked = true
                                    }
                            ) {
                                Text(
                                    text = option,
                                    fontSize = 16.sp,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    }
                    if (isLocked) {
                        val buttonText = if (currentQuizIndex < quizSets.size - 1) "Continue" else "See Result"
                        Button(
                            onClick = {
                                if (currentQuizIndex < quizSets.size - 1) {
                                    results.add("Question ${currentQuiz.id}: ${if (selectedOption == currentQuiz.correctAnswer) "Correct" else "Wrong"}")
                                    currentQuizIndex++
                                    selectedOption = -1
                                    isLocked = false
                                } else {
                                    results.add("Question ${currentQuiz.id}: ${if (selectedOption == currentQuiz.correctAnswer) "Correct" else "Wrong"}")
                                    showResults = true
                                }
                            },
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .padding(top = 16.dp)
                        ) {
                            Text(text = buttonText)
                        }
                    }
                }
            }
        }
    } else {
        ResultsScreen(results)
    }
}

@Composable
fun ResultsScreen(results: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(text = "Results", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(results) { result ->
                Text(text = result, fontSize = 18.sp)
            }
        }
    }
}
