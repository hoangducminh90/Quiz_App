package com.example.heo_di_hoc

data class QuizSet(
    val id: Int,
    val question: String,
    val answer1: String,
    val answer2: String,
    val answer3: String,
    val answer4: String,
    val correctAnswer: Int
)
val Quiz0001 = listOf(
    QuizSet(
        id = 1,
        question = "What is the main ingredient in guacamole?",
        answer1 = "Tomatoes",
        answer2 = "Avocados",
        answer3 = "Onions",
        answer4 = "Lettuce",
        correctAnswer = 2
    ),
    QuizSet(
        id = 2,
        question = "What type of food is a croissant?",
        answer1 = "Pastry",
        answer2 = "Pizza",
        answer3 = "Pasta",
        answer4 = "Salad",
        correctAnswer = 1
    ),
    QuizSet(
        id = 3,
        question = "What is the most consumed meat in the world?",
        answer1 = "Beef",
        answer2 = "Pork",
        answer3 = "Chicken",
        answer4 = "Fish",
        correctAnswer = 3
    ),
    QuizSet(
        id = 4,
        question = "What is the main ingredient in hummus?",
        answer1 = "Chickpeas",
        answer2 = "Lentils",
        answer3 = "Kidney beans",
        answer4 = "Black beans",
        correctAnswer = 1
    ),
    QuizSet(
        id = 5,
        question = "What type of food is a tamale?",
        answer1 = "Soup",
        answer2 = "Sandwich",
        answer3 = "Dumpling",
        answer4 = "Stew",
        correctAnswer = 3
    )
)
val Quiz0002 = listOf(
    QuizSet(
        id = 1,
        question = "Ha Noi khong san xuat loai thuc pham nao sau day",
        answer1 = "Tomatoes",
        answer2 = "Avocados",
        answer3 = "Onions",
        answer4 = "Lettuce",
        correctAnswer = 2
    ),
    QuizSet(
        id = 2,
        question = "Nghe An co dac san la gi?",
        answer1 = "Pastry",
        answer2 = "Pizza",
        answer3 = "Pasta",
        answer4 = "Salad",
        correctAnswer = 1
    )
)

val Quiz0003 = listOf(
    QuizSet(
        id = 1,
        question = "aaaa",
        answer1 = "a",
        answer2 = "b",
        answer3 = "c",
        answer4 = "d",
        correctAnswer = 2
    ),
    QuizSet(
        id = 2,
        question = "vvv?",
        answer1 = "a",
        answer2 = "v",
        answer3 = "c",
        answer4 = "d",
        correctAnswer = 1
    )
)
val Quiz0004 = listOf(
    QuizSet(
        id = 1,
        question = "aaaa",
        answer1 = "a",
        answer2 = "b",
        answer3 = "c",
        answer4 = "d",
        correctAnswer = 2
    ),
    QuizSet(
        id = 2,
        question = "vvv?",
        answer1 = "a",
        answer2 = "v",
        answer3 = "c",
        answer4 = "d",
        correctAnswer = 1
    )
)
val Quiz0005 = listOf(
    QuizSet(
        id = 1,
        question = "aaaa",
        answer1 = "a",
        answer2 = "b",
        answer3 = "c",
        answer4 = "d",
        correctAnswer = 2
    ),
    QuizSet(
        id = 2,
        question = "vvv?",
        answer1 = "a",
        answer2 = "v",
        answer3 = "c",
        answer4 = "d",
        correctAnswer = 1
    )
)
val allQuizSets = listOf(Quiz0001, Quiz0002, Quiz0003, Quiz0004,Quiz0005)
